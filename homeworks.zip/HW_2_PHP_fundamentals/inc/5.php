<?php
	include "2.php";

	if($myAge>=18 && $myAge<=59) 
		echo "Вам ще працювати і працювати";
