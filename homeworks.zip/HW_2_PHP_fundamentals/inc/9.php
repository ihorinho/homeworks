<?php
	$day = 5;