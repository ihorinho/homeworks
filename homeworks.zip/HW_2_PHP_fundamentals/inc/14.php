<?php
$foo = "bar";
$bar = 10;

echo $$foo;