<?php
$a = "78";
$b = 78;

if ($a == $b) 
	echo "Рівні";
else
	echo "Не рівні";

