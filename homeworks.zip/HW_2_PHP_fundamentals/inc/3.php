<?php
	include "1.php";
	echo "Мене звати $myName";