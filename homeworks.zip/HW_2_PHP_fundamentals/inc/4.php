<?php
	$myAge = 26;
	echo "Мені $myAge років";