<?php
	$myAge = 26; 