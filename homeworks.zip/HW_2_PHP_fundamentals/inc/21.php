<?php
$a = 0;
var_dump((bool)$a);
//Будь-яке число, крім 0, при приведенні до типу Boolean дає true(1)