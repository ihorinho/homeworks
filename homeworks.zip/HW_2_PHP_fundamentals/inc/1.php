<?php
	$myName = "Ігор";