<?php
//This is comment
/*This is comment*/
#This is comment