<?php
$a = 6;
$b = 7;

echo $a > $b ? $a : $b;