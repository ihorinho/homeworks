<?php
$a = "78";
$b = 78;

var_dump( $a == $b);
