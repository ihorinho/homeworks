<?php
echo "Hello, world!<br>";
print("Hello, World!<br>");
var_dump("Hello, World");
