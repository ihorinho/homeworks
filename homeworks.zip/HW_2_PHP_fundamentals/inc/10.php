<?php
	include "9.php";
	switch ($day) {
		case 2:
		case 3:
		case 3:
		case 4:
		case 5:
			echo "Це робочий день";

	}