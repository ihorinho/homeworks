<nav>
	<li><a href="arrays_loops_tasks/simple/index.php">Задачі з GitHub</a></li>
	<li><a href="arrays_loops_tasks/with_form/index.php">Задачі з GitHub + форми</a></li>
</nav>