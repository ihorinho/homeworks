<nav>
	<li><a href="HW_1_resume/index.php">Домашка №1 Резюме</a></li>
	<li><a href="HW_1_resume_with_Bootstrap/index.php">Домашка №1 Резюме (з Bootstrap)</a></li>
	<li><a href="HW_2_PHP_fundamentals/index.php">Домашка №2 Задачі по основах PHP</a></li>
	<li><a href="index.php?id=4">Домашка №3 Масиви і цикли</a></li>
	<li><a href="CW_loops_and_books/">Аудит. робота 20_09 Книжки блоками і табл. множення</a></li>
	<li><a href="functions/index.php">Домашка Функції</a></li>
</nav>