# homeworks \n

CW - class work
HM - home work

Repository for PHP-Academy homeworks
HW_1 #Create a resume-page
HW_1_with_Bootstrap #The same task built with using Bootstrap
HW_2 #27 simple tasks on PHP-fundamentals
