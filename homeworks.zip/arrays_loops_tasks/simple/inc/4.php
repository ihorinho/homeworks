<?php
	$arr = array('green'=>'зеленый','red'=>'красный','blue'=>'голубой');
	echo "Ключі:<br/>";
	foreach ($arr as $key => $v) {
		echo "$key <br/>";
	}
	echo "<br/>Значення:<br/>";
	foreach ($arr as $value) {
		echo "$value <br/>";
	}
 ?>