<?php
for($i = 1; $i <= 5; $i++){
	for($j = 1; $j <= $i * 2; $j++){
		echo "x";
	}
	echo "<br/>";
}
?>