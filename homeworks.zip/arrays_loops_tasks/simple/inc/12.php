<?php
$n = 1000;
$num = 0;
while ($n > 50) {
	$num++;
	$n /= 2; 
}
echo $num;
?>