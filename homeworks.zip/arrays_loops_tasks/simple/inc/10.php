<?php
$counter = 11;
do {
	echo "$counter </br>";
} while($counter++ < 33);
?>