<?php
	$arr = ['html', 'css', 'php', 'js', 'jq'];
	foreach ($arr as $value) {
		echo "$value <br/>";
	}
?>